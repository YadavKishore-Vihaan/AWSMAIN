require('dotenv').config();
var http = require("https");
const axios = require('axios');
const express = require('express');
const bodyParser = require('body-parser');
const qs = require('querystring');
const ticket = require('./ticket');
const signature = require('./verifySignature');
const debug = require('debug')('slash-command-template:index');
const users = require('./users');

const apiUrl = 'https://slack.com/api';

const app = express();
var tempvar = ""
var ListOfIds = []
/*
 * Parse application/x-www-form-urlencoded && application/json
 * Use body-parser's `verify` callback to export a parsed raw body
 * that you need to use to verify the signature
 */

const rawBodyBuffer = (req, res, buf, encoding) => {
  if (buf && buf.length) {
    req.rawBody = buf.toString(encoding || 'utf8');
  }
};

app.use(bodyParser.urlencoded({verify: rawBodyBuffer, extended: true }));
app.use(bodyParser.json({ verify: rawBodyBuffer }));

app.get('/', (req, res) => {
  res.send('<h2>The Slash Command and Dialog app is running</h2> <p>Follow the' +
  ' instructions in the README to configure the Slack App and your environment variables.</p>');
});

app.post('/send_standup', (req, res) => {
  const body = req.body;

  const { text, trigger_id } = req.body;

  var str = text
  var usr = str.split(" ");
  str = usr
  j = 0
  for(x of usr)
  {
    str[j] = x.slice(1)
    j++
  }

var usrIds = []
k = 0


  const fetchAllUser = new Promise((resolve, reject) => {
    console.log("1");
    users.findalluser().then((result) => {
      debug(`Find user: ${x}`);
      for(i of result.data.members)
      {
          for (j of str)
          {
            if(String(i.name) == String(j)){
              usrIds[k]=i.id;
              k++;

            }
          }
      }
      resolve(result.data.members);
    }).catch((err) => { reject(err); });
  })



  
    fetchAllUser.then((result) => {
      console.log("2");
      usrIds[k] = body.user_id;
  
    }).catch((err) => { console.error(err); })


  setTimeout(() => {
  var attachments = [
    {
      text: 'Please accept to Send your report',
      callback_id: 'accept_report',
      actions: [
        {
          name: 'accept_tos',
          text: 'Accept',
          value: 'accept',
          type: 'button',
          style: 'primary',
        },
        {
          name: 'accept_tos',
          text: 'Deny',
          value: 'deny',
          type: 'button',
          style: 'danger',
        },
      ],
    }
  ];

  for(ids of usrIds){

  var message = {
    token: process.env.SLACK_ACCESS_TOKEN,
    channel: ids,
    as_user: true,
    attachments: JSON.stringify(attachments),
    text: `Standup started by ${body.user_name}`
}

var qr = qs.stringify(message);
  if (signature.isVerified(req)) {
    axios.post('https://slack.com/api/chat.postMessage', qr).then((result) => {
      debug('sendConfirmation: %o', result.data);
      //console.log(result.data)
      res.send("");
    }).catch((err) => {
      debug('sendConfirmation error: %o', err);
      //console.log(err);
    });
  } else {
    debug('Token mismatch');
    res.sendStatus(404);
  }

}

global.ListOfIds = usrIds
},1000);

});


/*
 * Endpoint to receive /helpdesk slash command from Slack.
 * Checks verification token and opens a dialog to capture more info.
 */
app.post('/command', (req, res) => {
  // extract the slash command text, and trigger ID from payload
  const { text, trigger_id } = req.body;
  //console.log(text);
  global.tempvar = text
  // Verify the signing secret
  if (signature.isVerified(req)) {
    // create the dialog payload - includes the dialog structure, Slack API token,
    // and trigger ID
    const dialog = {
      token: process.env.SLACK_ACCESS_TOKEN,
      trigger_id,
      dialog: JSON.stringify({
        title: 'Standup Report',
        callback_id: 'submit-ticket',
        submit_label: 'Submit',
        elements: [
          {
            label: 'Q1',
            type: 'text',
            name: 'question1',
            hint: 'What did you do yesterday',
          },
          {
            label: 'Q2',
            type: 'text',
            name: 'question2',
            hint: 'What do you plan on doing today?',
          },
          {
            label: 'Blockers',
            type: 'textarea',
            name: 'blockers',
            optional: true,
          },
          {
            label: 'Urgency',
            type: 'select',
            name: 'urgency',
            options: [
              { label: 'Low', value: 'Low' },
              { label: 'Medium', value: 'Medium' },
              { label: 'High', value: 'High' },
            ],
          },
        ],
      }),
    };

    // open the dialog by calling dialogs.open method and sending the payload
    axios.post(`${apiUrl}/dialog.open`, qs.stringify(dialog))
      .then((result) => {
        debug('dialog.open: %o', result.data);
        res.send('');
      }).catch((err) => {
        debug('dialog.open call failed: %o', err);
        res.sendStatus(500);
      });
  } else {
    debug('Verification token mismatch');
    res.sendStatus(404);
  }
});

/*
 * Endpoint to receive the dialog submission. Checks the verification token
 * and creates a Helpdesk ticket
 */
app.post('/interactive', (req, res) => {
  const body = JSON.parse(req.body.payload);
  console.log(req.body.payload);
  // check that the verification token matches expected value
  if (signature.isVerified(req)) {
    debug(`Form submission received: ${body.submission.trigger_id}`);
    // immediately respond with a empty 200 response to let
    // Slack know the command was received
    res.send('');

    // create Helpdesk ticket
    ticket.create(body.user.id, body.submission,global.tempvar);
  } else {
    debug('Token mismatch');
    res.sendStatus(404);
  }
});


app.post('/interactivebutton', (req, res) => {
  const body = JSON.parse(req.body.payload);
  //console.log(req.body.payload.trigger_id);

  if (signature.isVerified(req)) {
    //console.log(String(body));
    const { trigger_id } = body;
      if(String(body.callback_id) == "accept_report"){
        console.log("Inside");
        const dialog = {
          token: process.env.SLACK_ACCESS_TOKEN,
          trigger_id,
          dialog: JSON.stringify({
            title: 'Standup Report',
            callback_id: 'submit-ticket',
            submit_label: 'Submit',
            elements: [
              {
                label: 'Q1',
                type: 'text',
                name: 'question1',
                hint: 'What did you do yesterday',
              },
              {
                label: 'Q2',
                type: 'text',
                name: 'question2',
                hint: 'What do you plan on doing today?',
              },
              {
                label: 'Blockers',
                type: 'textarea',
                name: 'blockers',
                optional: true,
              },
              {
                label: 'Urgency',
                type: 'select',
                name: 'urgency',
                options: [
                  { label: 'Low', value: 'Low' },
                  { label: 'Medium', value: 'Medium' },
                  { label: 'High', value: 'High' },
                ],
              },
            ],
          }),
        };
    
        // open the dialog by calling dialogs.open method and sending the payload
        axios.post(`${apiUrl}/dialog.open`, qs.stringify(dialog))
          .then((result) => {
            debug('dialog.open: %o', result.data);
            res.send('');
          }).catch((err) => {
            debug('dialog.open call failed: %o', err);
            res.sendStatus(500);
          });
      }
      else{
      res.send('');
      console.log(global.ListOfIds);
        ticket.create(body.user.id, body.submission,global.ListOfIds);
    } 
    }
    else {
      debug('Token mismatch');
      res.sendStatus(404);
    }});







const server = app.listen(process.env.PORT || 5001, () => {
  console.log('Express server listening on port %d in %s mode', server.address().port, app.settings.env);
});
